# LAPA-Depth

LAPA-Depth extends LAPA with depth-aware features for LIBERO robot policy fine-tuning and rollout evaluation.

The repository supports:

- Stage-3 offline fine-tuning with precomputed depth features;
- online depth-feature extraction during rollout;
- split-service rollout evaluation to reduce GPU memory pressure;
- checkpoint and feature-alignment inspection utilities.

## Pipeline

### Stage-3 Offline Fine-Tuning

Training examples contain:

```text
RGB image + instruction + action label + precomputed depth feature
```

The depth feature is loaded from Stage-2.5 feature shards and injected into the LAPA-Depth policy. The LAPA language model and action head are fine-tuned, while the frozen components are used as fixed feature providers.

### Online Rollout

During evaluation, depth features are generated from the current simulator observation:

```text
LIBERO RGB observation
  -> baseline LAPA RGB feature server
  -> DepthAnythingV2 / Stage-2.5 depth branch
  -> LAPA-Depth policy server
  -> robot action
```

For memory-constrained machines, the RGB feature server, Stage-2.5 server, policy server, and simulator can run on separate GPUs.

## Important Files

```text
latent_pretraining/train.py                 Stage-3 training entry point
latent_pretraining/deploy.py                LAPA-Depth policy server
eval/lapa_rgb_feature_server.py             RGB feature extraction server
eval/stage25_feature_server.py              Stage-2.5 online feature server
eval/eval_libero_rollout_depth.py           LIBERO rollout evaluator
scripts/train_lapa_depth_suite.sh           Train one LIBERO suite
scripts/eval_lapa_depth_split_online_rollout.sh
scripts/eval_lapa_depth_split_multi_suite.sh
scripts/inspect_lapa_depth_alignment.sh
scripts/inspect_lapa_depth_policy_split.sh
scripts/smoke_stage25_online_feature.sh
```

## Environment

Use Python 3.10 with CUDA-compatible PyTorch and JAX. Install dependencies in an isolated environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If your model server and LIBERO evaluator require different environments, set:

```bash
export MODEL_PY=/path/to/model/python
export LIBERO_PY=/path/to/libero/python
```

Otherwise the scripts use the active `python` by default.

## Repository Setup

From the repository root:

```bash
export LAPA_ROOT="$(pwd -P)"
export PYTHONPATH="$LAPA_ROOT:${PYTHONPATH:-}"
```

Place or symlink the LIBERO repository at:

```text
datasets/LIBERO
```

Then add it to `PYTHONPATH`:

```bash
export LIBERO_REPO="$LAPA_ROOT/datasets/LIBERO"
export PYTHONPATH="$LIBERO_REPO:$LAPA_ROOT:${PYTHONPATH:-}"
```

Follow the official LIBERO instructions to install dependencies and prepare assets, BDDL files, and initial states.

## Expected Data Layout

The scripts are configurable, but this layout is recommended:

```text
LAPA/
  lapa_checkpoints/
    tokenizer.model
    vqgan/
    base_lapa/
    depth_model/
      model2.65000.pt
      model4.65000.pt
      model5.65000.pt
    stage_3_depth_inject/
      lapa-depth_stage3/
        128_batch_spatial/
        128_batch_object/
        128_batch_goal/
        128_batch_90/

  datasets/
    LIBERO/
    lapa_libero_v2/
      images/
      libero_spatial.jsonl
      libero_object.jsonl
      libero_goal.jsonl
      libero_90.jsonl
      action_bins_libero_spatial.csv
      action_bins_libero_object.csv
      action_bins_libero_goal.csv
      action_bins_libero_90.csv
    features_depth_branch/
      stage25_libero_features_model4/

  Depth_branch/
  third_party/
    depth_anything_v2/
  checkpoints/
    depth_anything_v2_sth2sth/
      depth_anything_v2_sth2sth.pth
```

## Inspect Depth Feature Alignment

Before training, verify that JSONL rows match the precomputed depth features:

```bash
export SUITE=libero_spatial
export LAPA_JSONL="$LAPA_ROOT/datasets/lapa_libero_v2/${SUITE}.jsonl"
export DEPTH_DATA_DIR="$LAPA_ROOT/datasets/features_depth_branch/stage25_libero_features_model4/${SUITE}/stage25_model4/z_depth_train_shard0"
export DEPTH_MANIFEST="$DEPTH_DATA_DIR/z_depth_train_shard0_model4_manifest.json"

bash scripts/inspect_lapa_depth_alignment.sh
```

The match rate should be close to `1.0` before launching a full run.

## Train One Suite

Example interactive run:

```bash
export SUITE=libero_spatial
export STAGE25_MODEL_NAME=model4
export TOTAL_STEPS=20000
export BATCH_SIZE=128
export MESH_DIM='!-1,4,1,1'
export EXPERIMENT_ID="128_batch_${STAGE25_MODEL_NAME}_${SUITE}"

bash scripts/train_lapa_depth_suite.sh
```

Useful checkpoint settings:

```bash
export SAVE_MODEL_FREQ=1000
export SAVE_MILESTONE_FREQ=1000
export SAVE_OPTIMIZER_STATE=True
export AUTORESUME=False
```

For exact resume, keep the same `EXPERIMENT_ID` and rerun with:

```bash
export SAVE_OPTIMIZER_STATE=True
export AUTORESUME=True
```

`streaming_train_state` is required for exact resume. `streaming_params` is the params-only checkpoint used for rollout.

## Online Feature Smoke Test

```bash
export RGB_IMAGE=/path/to/example.jpg
export INSTRUCTION="pick up the object and place it in the target location"
export STAGE25_MODEL_NAME=model4
export STAGE25_MODEL_CHECKPOINT="$LAPA_ROOT/lapa_checkpoints/depth_model/${STAGE25_MODEL_NAME}.65000.pt"

bash scripts/smoke_stage25_online_feature.sh \
  --rgb_image "$RGB_IMAGE" \
  --instruction "$INSTRUCTION" \
  --port 32823
```

For `model5`, the Stage-2.5 branch uses RGB features only. For `model2` and `model4`, the branch uses RGB features plus a depth image or online depth prediction.

## Split Online Rollout

Example single-suite rollout:

```bash
export SUITE=libero_spatial
export STAGE25_MODEL_NAME=model4
export FINETUNED_CHECKPOINT="params::$LAPA_ROOT/lapa_checkpoints/stage_3_depth_inject/lapa-depth_stage3/128_batch_spatial/streaming_params"
export ORIGINAL_LAPA_CHECKPOINT="params::$LAPA_ROOT/lapa_checkpoints/base_lapa/streaming_params"

export POLICY_CUDA_VISIBLE_DEVICES=0
export STAGE25_CUDA_VISIBLE_DEVICES=1
export RGB_CUDA_VISIBLE_DEVICES=2
export MUJOCO_EGL_DEVICE_ID=1

export TASK_IDS="0 1 2"
export N_EVAL_PER_TASK=5
export MAX_STEPS=500
export OUTPUT_DIR="$LAPA_ROOT/outputs/eval_${SUITE}_${STAGE25_MODEL_NAME}"

bash scripts/eval_lapa_depth_split_online_rollout.sh
```

Task IDs are space-separated.

## Multi-Suite Rollout

```bash
export SUITES="libero_spatial libero_object libero_goal libero_90"
export TASK_IDS="0 1 2 3 4 5 6 7 8 9"
export N_EVAL_PER_TASK=10
export MAX_STEPS=500
export OUTPUT_PREFIX="eval_lapa_depth"

bash scripts/eval_lapa_depth_split_multi_suite.sh
```

Check the checkpoint mapping before reporting results.

## Troubleshooting

Inspect service logs:

```bash
tail -n 200 outputs/server_logs/policy*.log
tail -n 200 outputs/server_logs/stage25*.log
tail -n 200 outputs/server_logs/rgb_feature*.log
```

Common issues:

- wrong suite checkpoint;
- wrong action-bin CSV;
- mismatched RGB feature checkpoint between offline feature generation and online rollout;
- missing LIBERO assets;
- GPU memory pressure;
- stale server process still occupying a port or GPU.

To stop old services:

```bash
pkill -u "$USER" -f 'latent_pretraining.deploy' || true
pkill -u "$USER" -f 'eval.stage25_feature_server' || true
pkill -u "$USER" -f 'eval.lapa_rgb_feature_server' || true
pkill -u "$USER" -f 'eval_libero_rollout_depth' || true
```

The first rollout episode can be slow because JAX/XLA, PyTorch, DepthAnythingV2, and MuJoCo may initialize or compile kernels.

## Reproducibility Checklist

Record the following before reporting results:

- commit hash;
- Python, CUDA, PyTorch, and JAX versions;
- GPU type and count;
- LIBERO version;
- suite and task IDs;
- checkpoint identifiers;
- Stage-2.5 model name;
- action-bin file;
- training steps and batch size;
- number of evaluation episodes;
- random seeds.

## License and Citation

This repository builds on LAPA, LIBERO, DepthAnythingV2, and related research code. Follow the licenses and citation requirements of the upstream projects and downloaded checkpoints.
